export default class Freshdesk {
  static options = {};

  static setIdentify() {
    // freshsales.identify({ Email: email }, { Email: email });
  }
}