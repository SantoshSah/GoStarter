// Return an empty string or other mock path to emulate the url that
// webpack provides via the file-loader
module.exports = '';
