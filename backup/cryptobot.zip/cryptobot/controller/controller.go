package controller

import (
	"cryptobot/app"
	"cryptobot/conf"
	"cryptobot/services/rates"
	"cryptobot/services/robot2"
	"cryptobot/services/trading"
	"net/http"
	"strings"
	"time"

	"github.com/dgrijalva/jwt-go"
	"github.com/gin-contrib/static"
	"github.com/gin-gonic/gin"
	cors "github.com/itsjamie/gin-cors"
)

// Controller implemented router of project
type Controller struct {
	Config conf.Main
	App    *app.App
	Gin    *gin.Engine

	// Service which executed all incoming from robots trades
	Core *trading.Service

	// Associated map userID -> his trading robot
	Robots *robot2.Service

	// Rates stories info about current currencies
	Rates *rates.Service

	// Dashboard includes all gathering info about user
	Dashboard Dashboard
}

// MyCustomClaims includes fields from jwt token.
type MyCustomClaims struct {
	UserID   int64  `json:"id"`
	Email    string `json:"email"`
	Language string `json:"language"`
	jwt.StandardClaims
}

func maxRequestsAtOnce(n int) gin.HandlerFunc {
	s := make(chan struct{}, n)
	return func(c *gin.Context) {
		s <- struct{}{}
		defer func() { <-s }()
		c.Next()
	}
}

func initGin() *gin.Engine {
	g := gin.New()
	g.Use(gin.Recovery())
	g.Use(maxRequestsAtOnce(50))
	g.Use(cors.Middleware(cors.Config{
		Origins:        "*",
		Methods:        "GET, PUT, POST, DELETE, OPTIONS",
		RequestHeaders: "Origin, Authorization, Content-Type",
		ExposedHeaders: "",
		MaxAge:         50 * time.Second,
	}))

	return g
}

func New(config conf.Main, rateService *rates.Service, application *app.App, tradingService *trading.Service, robots *robot2.Service) *Controller {
	return &Controller{
		Config: config,
		Gin:    initGin(),
		Rates:  rateService,
		App:    application,
		Core:   tradingService,
		Robots: robots,
	}
}

// Start initialize endpoints and launch http server.
func (c *Controller) Start() error {
	c.Gin.GET("/healthcheck", func(ctx *gin.Context) {
		ctx.String(http.StatusOK, "OK")
	})
	c.Gin.GET("/api/v1/login", c.login)

	// CMS endpoints. For access to this endpoints need access_token in header
	admin := c.Gin.Group("")
	admin.Use(c.checkAdminToken)
	admin.POST("/api/v1/signup", c.signUp)
	admin.POST("/api/v1/signin", c.signIn)
	admin.POST("/api/v1/deposit", c.deposit)
	admin.POST("/api/v1/withdraw", c.withdraw)
	admin.GET("/api/v1/users", c.getUsers)
	admin.GET("/api/v1/users/:userID", c.getUser)
	admin.PUT("/api/v1/users/:userID", c.changeMargin)
	admin.PUT("/api/v1/users/:userID/trade-bounds", c.changeTradeBounds)
	admin.POST("/api/v1/config", c.config)

	// We can't use just a.Gin.Serve here because Gin will say / collides with /v1 stuff.
	c.Gin.Use(c.checkCookie)
	c.Gin.Use(static.Serve("/", static.LocalFile("./dist", true)))
	c.Gin.Use(static.Serve("/trades", static.LocalFile("./dist", true)))

	private := c.Gin.Group("")
	private.Use(c.authentication)
	private.GET("/api/v1/exchange-rates", c.exchangeRates)
	private.GET("/api/v1/user-info", c.userInfo)
	private.GET("/api/v1/trade-stats", c.tradeStats)
	private.GET("/api/v1/trades", c.retrieveTrades)
	private.POST("/api/v1/trades", c.createTrade)
	private.GET("/api/v1/app-config", c.appConfig)
	private.POST("/api/v1/bot-toggle", c.startTrading)
	private.GET("/api/v1/dashboard-info", c.dashboardInfo)
	private.GET("/api/v1/tour-visited", c.getTourVisited)
	private.POST("/api/v1/tour-visited", c.setTourVisited)
	private.POST("/api/v1/logout", c.logout)
	return c.Gin.Run(":" + c.Config.Port)
}

func (c *Controller) authentication(ctx *gin.Context) {
	tokenString := ctx.Request.Header.Get("Authorization")
	tokenString = strings.TrimPrefix(tokenString, "Bearer ")
	if tokenString == "" {
		ctx.Redirect(http.StatusFound, c.Config.FE.IJRP)
		ctx.Abort()
		return
	}
	token, err := jwt.ParseWithClaims(tokenString, &MyCustomClaims{}, func(token *jwt.Token) (interface{}, error) {
		return []byte(c.Config.Auth.JWTSecret), nil
	})
	if err != nil {
		ctx.Redirect(http.StatusFound, c.Config.FE.IJRP)
		ctx.Abort()
		return
	}
	if claims, ok := token.Claims.(*MyCustomClaims); ok && token.Valid {
		u := app.User{}
		if err := c.App.DB.Where("id = ?", claims.UserID).First(&u).Error; err != nil {
			ctx.JSON(http.StatusNotFound, gin.H{
				"error": err.Error(),
			})
			ctx.Abort()
			return
		}
		ctx.Set("user", &u)
	} else {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error": "can't get fields from jwt token",
		})
		ctx.Abort()
		return
	}
	ctx.Next()
}

func (c *Controller) checkAdminToken(ctx *gin.Context) {
	accessToken := ctx.Request.Header.Get("Authorization")
	if accessToken != "Bearer "+c.Config.Auth.AccessToken {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"error": "access_token is not valid",
		})
		ctx.Abort()
	}
}

func (c *Controller) checkCookie(ctx *gin.Context) {
	if ctx.Request.URL.String() != "/" &&
		ctx.Request.URL.String() != "/#/" &&
		ctx.Request.URL.String() != "/trades" {
		return
	}

	var sToken string
	for _, cookie := range ctx.Request.Cookies() {
		if cookie.Name == "session_token" {
			sToken = cookie.Value
		}
	}
	if sToken == "" {
		ctx.Redirect(http.StatusFound, c.Config.FE.IJRP)
		ctx.Abort()
	}
	if _, err := jwt.ParseWithClaims(sToken, &MyCustomClaims{}, func(token *jwt.Token) (interface{}, error) {
		return []byte(c.Config.Auth.JWTSecret), nil
	}); err != nil {
		ctx.Redirect(http.StatusFound, c.Config.FE.IJRP)
		ctx.Abort()
	}
}

func userFromContext(ctx *gin.Context) (*app.User, bool) {
	iu, ok := ctx.Get("user")
	if !ok {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error": "not found user id in context",
		})
		return nil, false
	}
	u, ok := iu.(*app.User)
	if !ok {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error": "not found user id in context",
		})
		return nil, false
	}
	return u, true
}
