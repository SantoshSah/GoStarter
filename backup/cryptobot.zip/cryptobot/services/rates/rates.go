package rates

import (
	"cryptobot/conf"
	"cryptobot/helper"
	"encoding/json"
	"io/ioutil"
	"math/rand"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/jinzhu/gorm"
	"github.com/sirupsen/logrus"
)

// All current real and modify rates
type Service struct {
	Config conf.Rates

	// Real rates price (update each 10 minutes).
	rates map[string]float64

	// Modified rates price (update each 2-5 seconds).
	modifiedRates   []CurrencyRates
	modifiedRatesMx *sync.RWMutex
	RatesChan       chan CurrencyRates
	// DB implemented package link to database
	DB *gorm.DB

	// list of all available exchanges.
	exchanges []string

	// list of all available rates.
	currencies []string

	randGen *rand.Rand
}

// CurrencyRates include model of information returns from /v1/exchange-rates
type CurrencyRates struct {
	Currency     string  `json:"currency"`
	BuyPrice     float64 `json:"buyPrice"`
	SellPrice    float64 `json:"sellPrice"`
	BuyExchange  string  `json:"buyExchange"`
	SellExchange string  `json:"sellExchange"`
}

func New(db *gorm.DB, config conf.Rates) *Service {
	s := Service{
		Config:          config,
		rates:           make(map[string]float64),
		modifiedRatesMx: &sync.RWMutex{},
		currencies:      initCurrencies(db),
		exchanges:       initExchanges(db),
		randGen:         rand.New(rand.NewSource(time.Now().UnixNano())),
		RatesChan:       make(chan CurrencyRates),
	}

	// Get prices from min-api.cryptocompare.com
	err := s.fetchRates()
	for err != nil {
		logrus.WithError(err).Error("Failed get initial rates. Trying again after ten seconds")
		time.Sleep(time.Second * 10)
		err = s.fetchRates()
	}

	// Make modified rates
	for cur, _ := range s.rates {
		s.modifiedRates = append(s.modifiedRates, s.makeRandomRate(cur))
	}

	return &s
}

// Run the service
func (s *Service) Start() {

	updateRatesTicker := time.After(s.actualRatesUpdateInterval())
	updateModifiedRatesTicker := time.After(s.randomRatesUpdateInterval())

	for {
		select {
		case <-updateRatesTicker:
			if err := s.fetchRates(); err != nil {
				logrus.WithError(err).Error("Failed update rates")
				updateRatesTicker = time.After(s.actualRatesUpdateInterval())
			}
		case <-updateModifiedRatesTicker:
			i := s.randGen.Intn(len(s.currencies))
			name := s.currencies[i]
			s.modifiedRatesMx.Lock()
			s.modifiedRates[i] = s.makeRandomRate(name)
			s.modifiedRatesMx.Unlock()
			select {
			case s.RatesChan <- s.modifiedRates[i]:
			default:
			}
			// fmt.Printf("new rates: %+v\n", s.modifiedRates[i])

			updateModifiedRatesTicker = time.After(s.randomRatesUpdateInterval())
		}
	}
}

func (s *Service) actualRatesUpdateInterval() time.Duration {
	return time.Second * time.Duration(s.Config.RatesUpdate)
}

func (s *Service) randomRatesUpdateInterval() time.Duration {
	t := (s.randGen.Intn(1+s.Config.RateUpdateMaxMS-s.Config.RateUpdateMinMS) + s.Config.RateUpdateMinMS) / len(s.currencies) / 3
	return time.Millisecond * time.Duration(t)
}

func (s *Service) makeRandomRate(curName string) CurrencyRates {
	buyExchange, sellExchange := s.randExchanges()
	r := CurrencyRates{
		Currency:     curName,
		BuyPrice:     s.randCurrencyPrice(curName, s.Config.BuyMinPer, s.Config.BuyMaxPer),
		SellPrice:    s.randCurrencyPrice(curName, s.Config.SellMinPer, s.Config.SellMaxPer),
		BuyExchange:  buyExchange,
		SellExchange: sellExchange,
	}
	return r
}

func (s *Service) randCurrencyPrice(currName string, min, max float64) float64 {
	t := s.randGen.Float64()
	t = t*(max-min) + min
	return helper.Round(s.rates[currName]*t, 8)
}

func (s *Service) GetRates() []CurrencyRates {
	s.modifiedRatesMx.RLock()
	defer s.modifiedRatesMx.RUnlock()
	r := make([]CurrencyRates, len(s.modifiedRates))
	copy(r, s.modifiedRates)
	return r
}

// fetchRates requested all rates from min-api.cryptocompare.com
func (s *Service) fetchRates() error {
	url := "https://min-api.cryptocompare.com/data/pricemulti?tsyms=BTC&fsyms=" + strings.Join(s.currencies, ",")

	resp, err := http.Get(url)
	if err != nil {
		return err
	}
	contents, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	if err = resp.Body.Close(); err != nil {
		logrus.WithError(err).Error("Failed close response body")
	}

	var prices map[string]map[string]float64
	if err = json.Unmarshal(contents, &prices); err != nil {
		return err
	}
	for name, price := range prices {
		if _, ok := price["BTC"]; !ok {
			logrus.Errorf("Unexpected response from cryptocompare.com.\nRaw response: %s", contents)
			continue
		}
		s.rates[name] = price["BTC"]
	}
	return nil
}

func initCurrencies(db *gorm.DB) []string {
	var Currencies []struct {
		Name string
	}
	if err := db.Table("currencies").Find(&Currencies).Error; err != nil {
		panic(err)
	}
	if len(Currencies) < 1 {
		panic("In database lacks rates")
	}
	var resp []string
	for _, e := range Currencies {
		resp = append(resp, e.Name)
	}
	return resp
}

func (s *Service) randExchanges() (string, string) {
	c1 := s.randGen.Intn(len(s.exchanges))
	c2 := s.randGen.Intn(len(s.exchanges))
	if c1 == c2 {
		return s.randExchanges()
	}
	return s.exchanges[c1], s.exchanges[c2]
}

func initExchanges(db *gorm.DB) []string {
	var Exchanges []struct {
		Name string
	}
	if err := db.Table("exchanges").Find(&Exchanges).Error; err != nil {
		panic(err)
	}
	if len(Exchanges) < 2 {
		panic("In database lacks exchanges")
	}
	var response []string
	for _, e := range Exchanges {
		response = append(response, e.Name)
	}
	return response
}
